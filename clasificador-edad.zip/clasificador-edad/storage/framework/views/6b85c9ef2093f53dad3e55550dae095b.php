<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Adolescentes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-warning d-flex flex-column justify-content-center align-items-center min-vh-100">
    <div class="text-center">
        <h1 class="display-5">¡Hola, Adolescente!</h1>
        <p class="lead">Bienvenido al portal de salud especialmente diseñado para ti.</p>
        <img src="https://centromedicorespirar.com/wp-content/uploads/2024/02/adolescente1.jpg" width="420" alt="Adolescente">
    </div>
</body>
</html>
<?php /**PATH C:\Users\Liak\Documents\Universidad\Octavo Semestre\Software seguro\Primer Parcial\clasificador-edad\resources\views/edad/adolescentes.blade.php ENDPATH**/ ?>